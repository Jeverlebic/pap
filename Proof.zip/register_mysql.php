﻿<?php 
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
//*************************************para eliminar a variável session $_SESSION['permissao'] depois de logout******

//******evita que se introduza diretamento o link no browser e entre*******
if (!isset($_POST['username']))
	{
		header('Location:/register.php');
		exit();		
	}

//*************************************************************************

include ($_SERVER['DOCUMENT_ROOT']."/database.php"); //script de acesso à base de dados

//******************************deteta se o user existe********************************
$select = "SELECT 
				username
			FROM 
				user
			WHERE username ='".$_POST['username']. "' 
			LIMIT 1" ;
$resultado = mysqli_query($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);

if($numero_de_linhas==0)
	{
		if( $_POST['password'] == $_POST['password2'] )
		{

			$insert = "INSERT INTO `user`( `username`, `password`, `email`, `shots`, `del`, `perm_id`) 
						VALUES ('".$_POST['username']. "', PASSWORD('".$_POST['password']. "') , '".$_POST['email']. "',3,0,2)" ;
			$resultado = mysqli_query($conn, $insert);
			
			
			$_SESSION['user'] = $_POST['username']; 
			$_SESSION['pass'] = $_POST['password'];

			echo  $_SESSION['user'];
			echo  $_SESSION['pass'];
			
			exit();
			header('Location:/login.php');


		}
		else //password != password 2
		{
			$_SESSION['passwords_diferentes']= "1";
			mysqli_close($conn);
			header('Location:/register.php');
			exit();

		}
	}

else
	{ 
		$_SESSION['utilizador_ja_existe']= "1";
		mysqli_close($conn);
		header('Location:/register.php');
		exit();
	}


?>