<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">
  <title>
    Blk• Design System by Creative Tim
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/blk-design-system.css?v=1.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <!-- CSS costum to my own project -->
  <link href="../assets/css/design.css" rel="stylesheet" />
</head>

<body class="index-page">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg fixed-top navbar-transparent " color-on-scroll="100">
    <div class="container">
      <div class="navbar-translate">
        <a class="navbar-brand" href="" rel="tooltip" title="Designed and Coded by Creative Tim" data-placement="bottom" target="_blank">
          <img src="../assets/img/sptv.png" alt="" height="40px" >   World class quality movies
        </a>
        <button class="navbar-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-bar bar1"></span>
          <span class="navbar-toggler-bar bar2"></span>
          <span class="navbar-toggler-bar bar3"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse justify-content-end" id="navigation">
        <div class="navbar-collapse-header">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a>
                <img src="./assets/img/sptv.png" alt="">
              </a>
            </div>
            <div class="col-6 collapse-close text-right">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
            </div>
          </div>
        </div>
        <ul class="navbar-nav">
          <li class="dropdown nav-item">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <i class="fa fa-cogs d-lg-none d-xl-none"></i>  <p style=" padding-top: 6px; padding-right: 10px; text-transform: capitalize; ">  <?php echo 	$_SESSION['utilizador']; ?> </p> <img class="perfil" src="../assets/img/square1.png" alt="imagem aqui">  &emsp;
            </a>
            <div class="dropdown-menu dropdown-with-icons">
              <a href="https://demos.creative-tim.com/blk-design-system/docs/1.0/getting-started/overview.html" class="dropdown-item">
                <i class="tim-icons icon-single-02"></i> Perfil
              </a>
              <a href="examples/register-page.html" class="dropdown-item">
                <i class="tim-icons icon-bullet-list-67"></i>Register Page
              </a>
              <a href="examples/landing-page.html" class="dropdown-item">
                <i class="tim-icons icon-image-02"></i>Landing Page
              </a>
              <a href="examples/profile-page.html" class="dropdown-item" style=" color: red; " >
                <i class="tim-icons icon-simple-remove"></i> Terminar Sessão
              </a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->

    <div class="main">

      <div class="section section-tabs">
        <div class="container">
          <div class="title">
            <h3 class="mb-3"style="text-transform: capitalize; ">Bem-vindo, <?php echo 	$_SESSION['utilizador']; ?> </h3>
          </div>
          <div class="row">
            <div class="col-md-10 ml-auto col-xl-12 mr-auto">
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Painel Administrador</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">
                <div class="card-header">
                  <ul class="nav nav-tabs nav-tabs-primary" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" data-toggle="tab" href="#link1" role="tablist">
                        <i class="tim-icons icon-video-66"></i> Filmes
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#link2" role="tablist">
                        <i class="tim-icons icon-single-02"></i> Utilizadores
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#link3" role="tablist">
                        <i class="tim-icons icon-bag-16"></i> Options
                      </a>
                    </li>
                  </ul>
                </div>
                <div class="card-body">
                  <!-- Tab panes -->
                  <div class="tab-content tab-space">
                    <div class="tab-pane active" id="link1">
                      <ul class="nav nav-pills nav-pills-primary nav-pills-icons">
                        <li class="nav-item">
                          <a class="nav-link active show" data-toggle="tab" href="">
                            <i class="tim-icons icon-atom"></i> Home
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-toggle="tab" href="#link8">
                            <i class="tim-icons icon-chat-33"></i> Messages
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-toggle="tab" href="#link9">
                            <i class="tim-icons icon-settings-gear-63"></i> Settings
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="tab-pane" id="link2">
                      <p>Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas.
                        <br />
                        <br/>Dynamically innovate resource-leveling customer service for state of the art customer service.</p>
                    </div>
                    <div class="tab-pane" id="link3">
                      <p>Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas.
                        <br />
                        <br/> Dramatically maintain clicks-and-mortar solutions without functional solutions.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Section Tabs -->
      <div class="section section-pagination">
        <img src="assets/img/path4.png" class="path">
        <img src="assets/img/path5.png" class="path path1">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <h3 class="mb-4">Progress Bars</h3>
              <div class="progress-container">
                <span class="progress-badge">Default</span>
                <div class="progress">
                  <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 25%;">
                    <span class="progress-value">25%</span>
                  </div>
                </div>
              </div>
              <div class="progress-container progress-primary">
                <span class="progress-badge">Primary</span>
                <div class="progress">
                  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                    <span class="progress-value">60%</span>
                  </div>
                </div>
              </div>
              <br>
              <h3 class="mb-5">Navigation Pills</h3>
              <ul class="nav nav-pills nav-pills-primary nav-pills-icons">
                <li class="nav-item">
                  <a class="nav-link active show" data-toggle="tab" href="#link7">
                    <i class="tim-icons icon-atom"></i> Home
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#link8">
                    <i class="tim-icons icon-chat-33"></i> Messages
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#link9">
                    <i class="tim-icons icon-settings-gear-63"></i> Settings
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-6">
              <h3 class="mb-5">Pagination</h3>
              <ul class="pagination pagination-primary">
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">2</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">3</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">4</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">5</a>
                </li>
              </ul>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#link" aria-label="Previous">
                    <span aria-hidden="true"><i class="tim-icons icon-double-left" aria-hidden="true"></i></span>
                  </a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">1</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#link">2</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link">3</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#link" aria-label="Next">
                    <span aria-hidden="true"><i class="tim-icons icon-double-right" aria-hidden="true"></i></span>
                  </a>
                </li>
              </ul>
              <br>
              <h3 class="mb-5">Labels</h3>
              <span class="badge badge-default">Default</span>
              <span class="badge badge-primary">Primary</span>
              <span class="badge badge-success">Success</span>
              <span class="badge badge-info">Info</span>
              <span class="badge badge-warning">Warning</span>
              <span class="badge badge-danger">Danger</span>
              <span class="badge badge-neutral">Neutral</span>
            </div>
          </div>
          <br>
        </div>
      </div>
      <div class="section section-notifications" id="notifications">
        <div class="container">
          <div class="space"></div>
          <h3>Notifications</h3>
          <div class="alert alert-primary alert-with-icon">
            <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
              <i class="tim-icons icon-simple-remove"></i>
            </button>
            <span data-notify="icon" class="tim-icons icon-coins"></span>
            <span>
              <b> Congrats! - </b> This is a regular notification made with ".alert-primary"</span>
          </div>
          <div class="alert alert-info alert-with-icon">
            <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
              <i class="tim-icons icon-simple-remove"></i>
            </button>
            <span data-notify="icon" class="tim-icons icon-trophy"></span>
            <span>
              <b> Heads up! - </b> This is a regular notification made with ".alert-info"</span>
          </div>
          <div class="alert alert-success alert-with-icon">
            <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
              <i class="tim-icons icon-simple-remove"></i>
            </button>
            <span data-notify="icon" class="tim-icons icon-bell-55"></span>
            <span>
              <b> Well done! - </b> This is a regular notification made with ".alert-success"</span>
          </div>
          <div class="alert alert-warning alert-with-icon">
            <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
              <i class="tim-icons icon-simple-remove"></i>
            </button>
            <span data-notify="icon" class="tim-icons icon-bulb-63"></span>
            <span>
              <b> Warning! - </b> This is a regular notification made with ".alert-warning"</span>
          </div>
          <div class="alert alert-danger alert-with-icon">
            <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
              <i class="tim-icons icon-simple-remove"></i>
            </button>
            <span data-notify="icon" class="tim-icons icon-support-17"></span>
            <span>
              <b> Oh snap! - </b> This is a regular notification made with ".alert-danger"</span>
          </div>
        </div>
      </div>
      <!--  end notifications -->
      <!-- Typography -->
      <div class="section section-typo">
        <img src="assets/img/path1.png" class="path">
        <img src="assets/img/path3.png" class="path path1">
        <div class="container">
          <h3 class="title">Typography</h3>
          <div id="typography">
            <div class="row">
              <div class="col-md-12">
                <div class="typography-line">
                  <h1>
                    <span>Header 1</span>The Life of BLK• Design System </h1>
                </div>
                <div class="typography-line">
                  <h2>
                    <span>Header 2</span>The Life of BLK• Design System</h2>
                </div>
                <div class="typography-line">
                  <h3>
                    <span>Header 3</span>The Life of BLK• Design System</h3>
                </div>
                <div class="typography-line">
                  <h4>
                    <span>Header 4</span>The Life of BLK• Design System</h4>
                </div>
                <div class="typography-line">
                  <h5>
                    <span>Header 5</span>The Life of BLK• Design System</h5>
                </div>
                <div class="typography-line">
                  <h6>
                    <span>Header 6</span>The Life of BLK• Design System</h6>
                </div>
                <div class="typography-line">
                  <p>
                    <span>Paragraph</span>
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at.
                  </p>
                </div>
                <div class="typography-line">
                  <span>Quote</span>
                  <blockquote>
                    <p class="blockquote blockquote-primary">
                      "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at."
                      <br>
                      <br>
                      <small>
                        - Noaa
                      </small>
                    </p>
                  </blockquote>
                </div>
                <div class="typography-line">
                  <span>Muted Text</span>
                  <p class="text-muted">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                  </p>
                </div>
                <div class="typography-line">
                  <span>Primary Text</span>
                  <p class="text-primary">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...</p>
                </div>
                <div class="typography-line">
                  <span>Info Text</span>
                  <p class="text-info">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers... </p>
                </div>
                <div class="typography-line">
                  <span>Success Text</span>
                  <p class="text-success">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers... </p>
                </div>
                <div class="typography-line">
                  <span>Warning Text</span>
                  <p class="text-warning">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                  </p>
                </div>
                <div class="typography-line">
                  <span>Danger Text</span>
                  <p class="text-danger">
                    I will be the leader of a company that ends up being worth billions of dollars, because I got the answers... </p>
                </div>
                <div class="typography-line">
                  <h2>
                    <span>Small Tag</span>
                    Header with small subtitle
                    <br>
                    <small>Use "small" tag for the headers</small>
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="space-50"></div>
          <div id="images">
            <h3 class="mb-5">Images</h3>
            <div class="row">
              <div class="col-sm-3 col-6">
                <small class="d-block text-uppercase font-weight-bold mb-4">Image</small>
                <img src="assets/img/ryan.jpg" alt="Rounded image" class="img-fluid rounded shadow" style="width: 150px;">
              </div>
              <div class="col-sm-3 col-6">
                <small class="d-block text-uppercase font-weight-bold mb-4">Circle Image</small>
                <img src="assets/img/james.jpg" alt="Circle image" class="img-fluid rounded-circle shadow" style="width: 150px;">
              </div>
              <div class="col-sm-3 col-6 mt-5 mt-sm-0">
                <small class="d-block text-uppercase font-weight-bold mb-4">Raised</small>
                <img src="assets/img/lora.jpg" alt="Raised image" class="img-fluid rounded shadow-lg" style="width: 150px;">
              </div>
              <div class="col-sm-3 col-6 mt-5 mt-sm-0">
                <small class="d-block text-uppercase font-weight-bold mb-4">Circle Raised</small>
                <img src="assets/img/mike.jpg" alt="Raised circle image" class="img-fluid rounded-circle shadow-lg" style="width: 150px;">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section section-javascript" id="javascriptComponents">
        <img src="assets/img/path5.png" class="path">
        <img src="assets/img/path5.png" class="path path1">
        <div class="container">
          <h3 class="title mb-5">Javascript components</h3>
          <h4 class="mb-5">Modal</h4>
          <div class="row" id="modals">
            <div class="col-md-4">
              <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                Launch Modal
              </button>
            </div>
            <div class="col-md-4">
              <button class="btn btn-warning" data-toggle="modal" data-target="#myModal1">
                Launch Modal Mini
              </button>
            </div>
            <div class="col-md-4">
              <button class="btn btn-success" data-toggle="modal" data-target="#myModal2">
                Launch Modal Form
              </button>
            </div>
          </div>
          <br />
          <br />
          <h4 class="mb-5 mt-3">Datepicker</h4>
          <div class="row">
            <div class="col-md-4">
              <div class="datepicker-container">
                <div class="form-group">
                  <input type="text" id="datepicker" class="form-control datepicker" value="10/05/2016" data-datepicker-color="primary">
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <h4 class="mb-5 mt-3">Popovers</h4>
              <button type="button" class="btn btn-default btn-sm" data-container="body" data-original-title="Popover on Top" data-toggle="popover" data-placement="top" data-content="Here will be some very useful information about his popover.">
                On top
              </button>
              <button type="button" class="btn btn-default btn-sm" data-container="body" data-original-title="Popover on Right" data-toggle="popover" data-placement="right" data-content="Here will be some very useful information about his popover.<br> Here will be some very useful information about his popover.">
                On right
              </button>
              <button type="button" class="btn btn-default btn-sm" data-container="body" data-original-title="Popover on Bottom" data-toggle="popover" data-placement="bottom" data-content="Here will be some very useful information about his popover.">
                On bottom
              </button>
              <button type="button" class="btn btn-default btn-sm" data-container="body" data-original-title="Popover On Left" data-toggle="popover" data-placement="left" data-content="Here will be some very useful information about his popover." data-color="primary">
                On left
              </button>
            </div>
            <div class="col-md-6">
              <h4 class="mb-5 mt-3">Tooltips</h4>
              <button type="button" class="btn btn-default btn-tooltip btn-sm" data-toggle="tooltip" data-placement="left" title="Tooltip on left" data-container="body" data-animation="true" data-delay="100">On left</button>
              <button type="button" class="btn btn-default btn-tooltip btn-sm" data-toggle="tooltip" data-placement="top" title="Tooltip on top" data-container="body" data-animation="true">On top</button>
              <button type="button" class="btn btn-default btn-tooltip btn-sm" data-toggle="tooltip" data-placement="bottom" title="Tooltip on bottom" data-container="body" data-animation="true">On bottom</button>
              <button type="button" class="btn btn-default btn-tooltip btn-sm" data-toggle="tooltip" data-placement="right" title="Tooltip on right" data-container="body" data-animation="true">On right</button>
              <div class="clearfix"></div>
              <br>
              <br>
            </div>
          </div>
        </div>
        <div class="section">
          <div class="container">
            <div class="title">
              <h3>Carousel</h3>
            </div>
            <div class="row justify-content-between align-items-center">
              <div class="col-lg-5 mb-5 mb-lg-0 ">
                <h1 class="text-white font-weight-light">Bootstrap carousel</h1>
                <p class="text-white mt-4">Black Design comes with three pre-built pages to help you get started faster. You can change the text and images and you're good to go.</p>
                <a href="./docs/1.0/components/alerts.html" class="btn btn-warning mt-4">See all components</a>
              </div>
              <div class="col-lg-6">
                <div id="carouselExampleControls" class="carousel slide">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img class="d-block w-100" src="assets/img/denys.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="assets/img/fabien-bazanegue.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="assets/img/mark-finn.jpg" alt="Third slide">
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <i class="tim-icons icon-minimal-left"></i>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <i class="tim-icons icon-minimal-right"></i>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section section-nucleo-icons">
        <img src="assets/img/path3.png" class="path">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-8 col-md-12">
              <h2 class="title">Nucleo Icons</h2>
              <h4 class="description">
                BLK• Design System PRO comes with 100 custom icons made by our friends from NucleoApp. The official package contains over 2.100 thin icons which are looking great in combination with BLK• Design System PRO Make sure you check all of them and use those that you like the most.
              </h4>
              <div class="btn-wrapper">
                <a href="./docs/1.0/foundation/icons.html" class="btn btn-primary btn-round" target="_blank">View Demo Icons</a>
                <a href="https://nucleoapp.com/?ref=1712" class="btn btn-primary btn-simple btn-round btn-lg" target="_blank">View All Icons</a>
              </div>
            </div>
          </div>
          <div class="blur-hover">
            <a href="./docs/1.0/foundation/icons.html">
              <div class="icons-container blur-item on-screen mt-5">
                <!-- Center -->
                <i class="icon tim-icons icon-coins"></i>
                <!-- Right 1 -->
                <i class="icon icon-sm tim-icons icon-spaceship"></i>
                <i class="icon icon-sm tim-icons icon-money-coins"></i>
                <i class="icon icon-sm tim-icons icon-link-72"></i>
                <!-- Right 2 -->
                <i class="icon tim-icons icon-send"></i>
                <i class="icon tim-icons icon-mobile"></i>
                <i class="icon tim-icons icon-wifi"></i>
                <!-- Left 1 -->
                <i class="icon icon-sm tim-icons icon-key-25"></i>
                <i class="icon icon-sm tim-icons icon-atom"></i>
                <i class="icon icon-sm tim-icons icon-satisfied"></i>
                <!-- Left 2 -->
                <i class="icon tim-icons icon-gift-2"></i>
                <i class="icon tim-icons icon-tap-02"></i>
                <i class="icon tim-icons icon-wallet-43"></i>
              </div>
              <span class="blur-hidden h5 text-primary">Eplore all the 21.000+ Nucleo Icons</span>
            </a>
          </div>
        </div>
      </div>
      <div class="section section-signup">
        <div class="container">
          <div class="squares square-1"></div>
          <div class="squares square-2"></div>
          <div class="squares square-3"></div>
          <div class="squares square-4"></div>
          <div class="row row-grid justify-content-between align-items-center">
            <div class="col-lg-6">
              <h3 class="display-3 text-white">A beautiful Black Design
                <span class="text-white">completed with examples</span>
              </h3>
              <p class="text-white mb-3">The Design System comes with four pre-built pages to help you get started faster. You can change the text and images and you're good to go. More importantly, looking at them will give you a picture of what you can built with this powerful Bootstrap 4 Design System.</p>
              <div class="btn-wrapper">
                <a href="examples/register-page.html" class="btn btn-info">Register Page</a>
              </div>
            </div>
            <div class="col-lg-6 mb-lg-auto">
              <div class="card card-register">
                <div class="card-header">
                  <img class="card-img" src="assets/img/square1.png" alt="Card image">
                  <h4 class="card-title">Register</h4>
                </div>
                <div class="card-body">
                  <form class="form">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="tim-icons icon-single-02"></i>
                        </div>
                      </div>
                      <input type="text" class="form-control" placeholder="Full Name">
                    </div>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="tim-icons icon-email-85"></i>
                        </div>
                      </div>
                      <input type="text" placeholder="Email" class="form-control">
                    </div>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="tim-icons icon-lock-circle"></i>
                        </div>
                      </div>
                      <input type="text" class="form-control" placeholder="Password">
                    </div>
                    <div class="form-check text-left">
                      <label class="form-check-label">
                        <input class="form-check-input" type="checkbox">
                        <span class="form-check-sign"></span>
                        I agree to the
                        <a href="javascript:void(0)">terms and conditions</a>.
                      </label>
                    </div>
                  </form>
                </div>
                <div class="card-footer">
                  <a href="javascript:void(0)" class="btn btn-info btn-round btn-lg">Get Started</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section section-examples" data-background-color="black">
        <img src="assets/img/path1.png" class="path">
        <div class="space-50"></div>
        <div class="container text-center">
          <div class="row">
            <div class="col-sm-6">
              <a href="examples/landing-page.html">
                <img src="assets/img/landing-page.png" alt="Image" class="img-raised">
              </a>
              <a href="examples/landing-page.html" class="btn btn-simple btn-primary btn-round">View Landing Page</a>
            </div>
            <div class="col-sm-6">
              <a href="examples/profile-page.html">
                <img src="assets/img/profile-page.png" alt="Image" class="img-raised">
              </a>
              <a href="examples/profile-page.html" class="btn btn-simple btn-primary btn-round">View Profile Page</a>
            </div>
          </div>
        </div>
      </div>
      <div class="section section-download" id="#download-section" data-background-color="black">
        <img src="assets/img/path1.png" class="path">
        <div class="container">
          <div class="row justify-content-md-center">
            <div class="text-center col-md-12 col-lg-8">
              <h2 class="title">Do you love this Bootstrap 4 Design System?</h2>
              <h4 class="description">Cause if you do, it can be yours for FREE. Hit the button below to navigate to Creative Tim where you can find the design system in HTML format. Start a new project or give an old Bootstrap project a new look!</h4>
            </div>
            <div class="text-center col-md-12 col-lg-8">
              <a href="https://www.creative-tim.com/product/blk-design-system" class="btn btn-primary btn-round btn-lg" role="button">
                Download HTML
              </a>
              <!-- <a href="https://www.invisionapp.com/now" target="_blank" class="btn btn-primary btn-lg btn-simple btn-round" role="button">
						Download PSD/Sketch
					</a> -->
            </div>
          </div>
          <br>
          <br>
          <br>
          <!-- <div class="row text-center mt-5">
				<div class="col-md-8 ml-auto mr-auto">
					<h2>Want more?</h2>
					<h5 class="description">We've just launched <a href="http://demos.creative-tim.com/black-kit-pro/presentation.html" target="_blank">BLK• Design System PRO</a>. It has a huge number of components, sections and example pages. Start Your Development With A Badass Bootstrap 4 Design System.</h4>
				</div>
				<div class="col-md-12">
					<a href="http://demos.creative-tim.com/black-kit-pro/presentation.html" class="btn btn-neutral btn-round btn-lg" target="_blank">
						<i class="tim-icons icon-cloud-upload-94"></i> Upgrade to PRO
					</a>
				</div>
			</div> -->
          <br>
          <br>
          <div class="row row-grid align-items-center my-md">
            <div class="col-lg-6">
              <h3 class="text-primary font-weight-light mb-2">Thank you for supporting us!</h3>
              <h4 class="mb-0 font-weight-light">Let's get in touch on any of these platforms.</h4>
            </div>
            <div class="col-lg-6 text-lg-center btn-wrapper">
              <a id="twitter" class="btn btn-icon btn-twitter btn-round btn-lg" data-toggle="tooltip" data-original-title="Tweet!">
                <i class="fab fa-twitter"></i>
              </a>
              <a id="facebook" class="btn btn-icon btn-facebook btn-round btn-lg" data-toggle="tooltip" data-original-title="Share!">
                <i class="fab fa-facebook-square"></i>
              </a>
              <a target="_blank" href="https://github.com/creativetimofficial" class="btn btn-icon btn-github btn-round btn-lg" data-toggle="tooltip" data-original-title="Star on Github">
                <i class="fab fa-github"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- Sart Modal -->
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header justify-content-center">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
              <h4 class="title title-up">Modal title</h4>
            </div>
            <div class="modal-body">
              <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.
              </p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default">Nice Button</button>
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
      <!--  End Modal -->
      <!-- Mini Modal -->
      <div class="modal fade modal-mini modal-primary modal-mini" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header justify-content-center">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                <i class="tim-icons icon-simple-remove text-white"></i>
              </button>
              <div class="modal-profile">
                <i class="tim-icons icon-single-02"></i>
              </div>
            </div>
            <div class="modal-body">
              <p>Always have an access to your profile</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-link btn-neutral">Back</button>
              <button type="button" class="btn btn-link btn-neutral" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Form Modal -->
      <div class="modal fade modal-black" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header justify-content-center">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                <i class="tim-icons icon-simple-remove text-white"></i>
              </button>
              <div class="text-muted text-center ml-auto mr-auto">
                <h3 class="mb-0">Sign in with</h3>
              </div>
            </div>
            <div class="modal-body">
              <div class="btn-wrapper text-center">
                <a href="#" class="btn btn-neutral btn-icon">
                  <img src="assets/img/github.svg">
                </a>
                <a href="#" class="btn btn-neutral btn-icon">
                  <img src="assets/img/google.svg">
                </a>
              </div>
              <div class="text-center text-muted mb-4 mt-3">
                <small>Or sign in with credentials</small>
              </div>
              <form role="form">
                <div class="form-group mb-3">
                  <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="tim-icons icon-email-85"></i>
                      </span>
                    </div>
                    <input class="form-control" placeholder="Email" type="email">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="tim-icons icon-key-25"></i>
                      </span>
                    </div>
                    <input class="form-control" placeholder="Password" type="password">
                  </div>
                </div>
                <div class="form-check mt-3">
                  <label class="form-check-label">
                    <input class="form-check-input" type="checkbox" checked>
                    <span class="form-check-sign"></span>
                    Remember me!
                  </label>
                </div>
                <div class="text-center">
                  <button type="button" class="btn btn-primary my-4">Sign in</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!--  End Modal -->
    </div>
    <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <h1 class="title">BLK•</h1>
          </div>
          <div class="col-md-3">
            <ul class="nav">
              <li class="nav-item">
                <a href="./index.html" class="nav-link">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a href="./examples/landing-page.html" class="nav-link">
                  Landing
                </a>
              </li>
              <li class="nav-item">
                <a href="./examples/register-page.html" class="nav-link">
                  Register
                </a>
              </li>
              <li class="nav-item">
                <a href="./examples/profile-page.html" class="nav-link">
                  Profile
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-3">
            <ul class="nav">
              <li class="nav-item">
                <a href="https://creative-tim.com/contact-us" class="nav-link">
                  Contact Us
                </a>
              </li>
              <li class="nav-item">
                <a href="https://creative-tim.com/about-us" class="nav-link">
                  About Us
                </a>
              </li>
              <li class="nav-item">
                <a href="https://creative-tim.com/blog" class="nav-link">
                  Blog
                </a>
              </li>
              <li class="nav-item">
                <a href="https://opensource.org/licenses/MIT" class="nav-link">
                  License
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-3">
            <h3 class="title">Follow us:</h3>
            <div class="btn-wrapper profile">
              <a target="_blank" href="https://twitter.com/creativetim" class="btn btn-icon btn-neutral btn-round btn-simple" data-toggle="tooltip" data-original-title="Follow us">
                <i class="fab fa-twitter"></i>
              </a>
              <a target="_blank" href="https://www.facebook.com/creativetim" class="btn btn-icon btn-neutral btn-round btn-simple" data-toggle="tooltip" data-original-title="Like us">
                <i class="fab fa-facebook-square"></i>
              </a>
              <a target="_blank" href="https://dribbble.com/creativetim" class="btn btn-icon btn-neutral  btn-round btn-simple" data-toggle="tooltip" data-original-title="Follow us">
                <i class="fab fa-dribbble"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
  <script src="../assets/js/plugins/bootstrap-switch.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
  <script src="../assets/js/plugins/moment.min.js"></script>
  <script src="../assets/js/plugins/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!-- Black Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <!-- Control Center for Black UI Kit: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/blk-design-system.min.js?v=1.0.0" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      blackKit.initDatePicker();
      blackKit.initSliders();
    });

    function scrollToDownload() {

      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
</body>

</html>
