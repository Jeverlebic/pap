﻿<?php 
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
//*************************************para eliminar a variável session $_SESSION['permissao'] depois de logout******

//******evita que se introduza diretamento o link no browser e entre*******
if (!isset($_POST['username']))
	{
		header('Location:/login.php');
		exit();		
	}

//*************************************************************************

include ($_SERVER['DOCUMENT_ROOT']."/database.php"); //script de acesso à base de dados

//******************************deteta se o user está eliminado********************************
$select = "SELECT username, del  FROM user 
			WHERE username ='".$_POST['username']. "' 
			AND del = 1
			LIMIT 1";
		
$resultado = mysqli_query ($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);
 

if($numero_de_linhas==1)
	{
		$_SESSION['utilizador_eliminado']= "1";
		mysqli_close($conn);
		header('Location:/login.php');
		exit();
	}
//*************************************************************************************

//******************************deteta se o user existe********************************
$select = "SELECT 
				username,
				shots,
				perm_id
			FROM 
				user
			WHERE username ='".$_POST['username']. "' 
			LIMIT 1" ;
	
$resultado = mysqli_query($conn, $select);

$numero_de_linhas = mysqli_num_rows($resultado);

if($numero_de_linhas==0)
	{
		$_SESSION['utilizador_nao_existe']= "1";
		mysqli_close($conn);
		header('Location:/login.php');
		exit();
	}
//*************************************************************************************
else
//*****************deteta se tem tentativas ou se está bloqueado na descrição**********
	{
		$linha=mysqli_fetch_array($resultado);
		if($linha["shots"]==0 || $linha["perm_id"]!=1)
			{
			$_SESSION['tentativas_zero']= "1";
			mysqli_close($conn);
			header('Location:/login.php');
			exit();	
			}
//**************************************************************************************
		else
			{
				
			$select = "SELECT * FROM `user` WHERE username ='".$_POST['username']. "'
						AND password = PASSWORD('".$_POST['password']. "') 
						LIMIT 1" ;
			$resultado = mysqli_query($conn, $select);
			$numero_de_linhas = mysqli_num_rows($resultado);

			if($numero_de_linhas==0)
				{
				$update="UPDATE user
							SET shots = shots-1 
								WHERE username ='".$_POST['username']."'
								LIMIT 1";
				mysqli_query($conn,$update);
				
				$_SESSION['tentativas_restantes']= $linha["shots"]-1;				
				$_SESSION['password_errada']= "1";
				
				if($_SESSION['tentativas_restantes']==0)
					{
					$update="UPDATE user
							SET perm_id = 3
								WHERE username ='".$_POST['username']."'
								LIMIT 1";
					mysqli_query($conn,$update);	
					}
				
				mysqli_close($conn);
				header('Location:/login.php');
				exit();
				}
			else
				{
				$update="UPDATE user
							SET shots = 3 
								WHERE user.username ='".$_POST['username']."'
								LIMIT 1";
				mysqli_query($conn,$update);
				
				$linha=mysqli_fetch_array($resultado);
				$_SESSION['permissao_utilizador']= $linha["perm_id"];
				$_SESSION['id_utilizador']= $linha["id"];
				$_SESSION['utilizador']= $linha["username"];
				$_SESSION['fotografia']= $linha["pic"];

				
//***************marca entrada na tabela dos logs******************************************
				$insert = "INSERT INTO `log`(`user_id`,`datein`)
								VALUES (".$linha["id"]." , NOW() )";
			
				mysqli_query($conn,$insert);				
				mysqli_close($conn);
//*****************************************************************************************
					$_SESSION['algo'] = 1;
				if($linha["perm_id"]==1) 
					{
						header('Location:/admin/dashboard.php');
					};
				if($linha["perm_id"]==2) 
					{
						header('Location:/user/dashboard.php.php');
					};
					
				
				exit();	
				}
			}
	}
?>